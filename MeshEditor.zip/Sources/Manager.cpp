#include "DXUT.h"
#include "strsafe.h"
#include "Manager.h"


//-------------------------------------------------------------------------------------------------------------------------------
// AutoSegmentation ��ư ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnAutoSegmentation(int val)
{
	if(m_pMesh == NULL)
		return;
	printf("OnAutoSegmentation()\n");
	m_pMesh->Segmentation(val);
}

//-------------------------------------------------------------------------------------------------------------------------------
// Merge ��ư ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnMerge()
{
	printf("OnMerge()\n");
	m_pMesh->Merge();
}

//-------------------------------------------------------------------------------------------------------------------------------
// Split ��ư ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnSplit()
{
	printf("OnSplit()\n");
	// ���õ� segment ���ų� �̹� split ���̸� return FALSE	
	m_bSplitNow = true;
}
//-------------------------------------------------------------------------------------------------------------------------------
// Flatten ��ư ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnFlattenSegment()
{
	printf("OnFlatten()\n");
	m_pMesh->Flatten();
}
//-------------------------------------------------------------------------------------------------------------------------------
// Load Mesh ��ư ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnLoadMesh()
{
	printf("OnLoadMesh()\n");

	OPENFILENAME ofn;
	char szFileName[MAX_PATH] = "";

	memset(&ofn, 0, sizeof(OPENFILENAME));

	ofn.lStructSize = sizeof(ofn);
	ofn.lpstrFilter = L"STL Files (*.stl)\0*.stl\0All Files (*.*)\0*.*\0";
	ofn.lpstrFile = (LPTSTR)szFileName;
	ofn.nMaxFile = MAX_PATH;
	ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY;
	ofn.lpstrInitialDir=L"..\\data";

	if(GetOpenFileName(&ofn))
	{
		char* path = GetMeshFileName(ofn);
		SAFE_DELETE(m_pMesh);
		m_pMesh = new CMesh(m_pD3DDevice, path);
		m_pMesh->LoadMesh();
	}
}

//-------------------------------------------------------------------------------------------------------------------------------
// ���콺 ���� ��ư ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnLButtonDown(void)
{
POINT ptCursor = GetCursorPosInClient();

	if(!m_bSplitNow)
	{			
		int facetId = Pick(ptCursor.x, ptCursor.y);
	
		if(facetId >= 0) 
		{
			int segmentId = m_pMesh->GetSelectedSegmentId(facetId);
			m_pMesh->SelectSegment(segmentId);
			m_pMesh->InitVertexBuffer();
		}	
	}
	else
	{
		if(!m_bPickStartPt)
		{
			SaveLinePosition(ptCursor.x, ptCursor.y, ptCursor.x, ptCursor.y);
			m_bPickStartPt = true;
			printf("������ ���콺 ��ǥ: %d, %d\n", m_LineStartX, m_LineStartY);
		}
		else 
		{
			m_bSplitNow = false;
			m_bPickStartPt = false;
			POINT ptCursor = GetCursorPosInClient();
			SaveLinePosition(m_LineStartX, m_LineStartY, ptCursor.x, ptCursor.y);			

			// Point in world space
			Point_3 LineStartPt	= PointToWorldSpace(m_LineStartX, m_LineStartY);
			Point_3 LineEndPt	= PointToWorldSpace(m_LineEndX, m_LineEndY);
			D3DXVECTOR3 vEyePt  = *(m_Camera.GetEyePt()); 
			Point_3 CameraEyePt	= Point_3(vEyePt.x, vEyePt.y, vEyePt.z);

			m_pMesh->Split(LineStartPt, LineEndPt, CameraEyePt);
			printf("���� ���콺 ��ǥ: %d, %d\n", m_LineEndX, m_LineEndY);
		}
	}
}

//-------------------------------------------------------------------------------------------------------------------------------
// ���콺 ���� ��ư ��
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnLButtonUp(void)
{

}

//-------------------------------------------------------------------------------------------------------------------------------
// ���콺 �̵�����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnMouseMove(void)
{
	POINT ptCursor = GetCursorPosInClient();
	SaveLinePosition(m_LineStartX, m_LineStartY, ptCursor.x, ptCursor.y);
}

//-------------------------------------------------------------------------------------------------------------------------------
// Split�� ���� �׸���
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::DrawLineSement(int x1, int y1, int x2, int y2)
{
	// ������ �׸���

	// ���� �׸���
	D3DXVECTOR2 vList[] = {
		D3DXVECTOR2(m_LineStartX, m_LineStartY),
		D3DXVECTOR2(m_LineEndX, m_LineEndY)
	};

	m_pLine->Begin();
	m_pLine->Draw(vList, 2, D3DCOLOR_XRGB(255, 255, 0));
	m_pLine->End();
}

//-------------------------------------------------------------------------------------------------------------------------------
// Split�� 2D���� �׸���
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::SaveLinePosition(int startX, int startY, int endX, int endY) 
{ 
	m_LineStartX = startX; 
	m_LineStartY = startY; 
	m_LineEndX = endX;
	m_LineEndY = endY;
}

//-------------------------------------------------------------------------------------------------------------------------------
// Ž��â���� ������ ������ �̸�(�������)�� ������
//-------------------------------------------------------------------------------------------------------------------------------
char* CManager::GetMeshFileName(OPENFILENAME& ofn)
{
	static char path[MAX_PATH];
	memset(path, 0, MAX_PATH);
	wcstombs(path, ofn.lpstrFile, MAX_PATH);
	return path;
}

//-------------------------------------------------------------------------------------------------------------------------------
// Ű�Է� ó��
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::OnKeyboard(UINT key)
{

}

//-------------------------------------------------------------------------------------------------------------------------------
// �޽��� ���ν���
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{	
	m_Camera.HandleMessages( hWnd, uMsg, wParam, lParam );
}

//-------------------------------------------------------------------------------------------------------------------------------
// �ؽ�Ʈ ���
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::DrawText(CDXUTTextHelper* pTxtHelper)
{
	WCHAR text[256];

	StringCchPrintf(text, 256, 
		L"���ʹ�ư: Segment ����, �ٹ�ư: ī�޶� ����/�ƿ�, �����ʹ�ư: ī�޶� ȸ��");
	pTxtHelper->DrawTextLine(text);

	D3DXVECTOR3 vCameraEye = *(m_Camera.GetEyePt());
	StringCchPrintf(text, 256, L"ī�޶� ��ġ: %0.2f, %0.2f, %0.2f", 
		vCameraEye.x, vCameraEye.y, vCameraEye.z);
	pTxtHelper->DrawTextLine(text);
}

//-------------------------------------------------------------------------------------------------------------------------------
// ��ŷ�� segment�� id�� ������
//-------------------------------------------------------------------------------------------------------------------------------
int CManager::Pick(int x, int y)
{
	if(m_pMesh == NULL) return -1;
	
	// Ray ���
	CRay ray = CalcPickRay(x, y);	

	// ray �������� ���� ����� facet�� index ���ϱ�
	const Face_handle faceHandle = 
		GetFaceHandleOfPickedFacet(ray.GetStartPt(), ray.GetEndPt());

	if(faceHandle == NULL) 
		return -1;
	else
		return faceHandle->getFacetId();
}

//-------------------------------------------------------------------------------------------------------------------------------
// ��ű�� ray(������, ����) ���
//-------------------------------------------------------------------------------------------------------------------------------
CRay CManager::CalcPickRay(int x, int y)
{
	// Compute the vector of the pick ray in screen space
	D3DXVECTOR3 vec;
	const D3DSURFACE_DESC* pd3dsdBackBuffer = DXUTGetD3D9BackBufferSurfaceDesc();
	vec.x = ( ( ( 2.0f * x ) / pd3dsdBackBuffer->Width ) - 1 );
	vec.y = -( ( ( 2.0f * y ) / pd3dsdBackBuffer->Height ) - 1 );
	vec.z = 0.000001f;

	// Get the inverse view matrix
	D3DXMATRIX mViewProj = m_mCameraView * m_mCameraProj;
	D3DXMATRIX mInverse;
	D3DXMatrixInverse( &mInverse, NULL, &mViewProj );

	// Transform the screen space pick ray into 3D space
	D3DXVECTOR3 vStart, vEnd;

	D3DXVec3TransformCoord(&vStart, &vec, &mInverse);
	D3DXVECTOR3 vLookAt = vStart - *(m_Camera.GetEyePt());
	D3DXVec3Normalize(&vLookAt, &vLookAt);
	vLookAt *= 1000.f;
	vEnd = vStart + vLookAt;

	CRay ray(vStart, vEnd);
	return ray;
}

//-------------------------------------------------------------------------------------------------------------------------------
// Screen space ��ǥ�� World space ��ǥ�� ��ȯ
//-------------------------------------------------------------------------------------------------------------------------------
Point_3 CManager::PointToWorldSpace(int x, int y)
{
	// Compute the vector of the pick ray in screen space
	D3DXVECTOR3 vec;
	const D3DSURFACE_DESC* pd3dsdBackBuffer = DXUTGetD3D9BackBufferSurfaceDesc();
	vec.x = ( ( ( 2.0f * x ) / pd3dsdBackBuffer->Width ) - 1 );
	vec.y = -( ( ( 2.0f * y ) / pd3dsdBackBuffer->Height ) - 1 );
	vec.z = 0.000001f;

	// Get the inverse view matrix
	D3DXMATRIX mViewProj = m_mCameraView * m_mCameraProj;
	D3DXMATRIX mInverse;
	D3DXMatrixInverse( &mInverse, NULL, &mViewProj );

	// Transform the screen space pick ray into 3D space	
	D3DXVec3TransformCoord(&vec, &vec, &mInverse);

	return Point_3(vec.x, vec.y, vec.z);
}

//-------------------------------------------------------------------------------------------------------------------------------
// ��ŷ�� facet�� handle ����
//-------------------------------------------------------------------------------------------------------------------------------
Face_handle CManager::GetFaceHandleOfPickedFacet(const Point_3& startPt, const Point_3& endPt)
{
	Polyhedron& polyhedron = m_pMesh->GetPolyhedron();

	// AABB tree ����
	Tree tree(polyhedron.facets_begin(), polyhedron.facets_end(), polyhedron);

	// ray ����
	Segment_3 ray(startPt, endPt);

	// ray�� �����ϴ� facet�� primitive id ���
	std::list<Primitive_id> primitives;
	tree.all_intersected_primitives(ray, std::back_inserter(primitives));

	if(!tree.do_intersect(ray)) {
		printf("���õ� facet ����\n");
		return NULL;	
	}

	// primitive id�� �̿��� ������ facet�� index ã��
	std::vector<size_t> indexOfIntersectedFacet;
	std::list<Primitive_id>::iterator id_itor;

	for(id_itor = primitives.begin(); id_itor != primitives.end(); id_itor++)
	{
		std::size_t index = std::distance(polyhedron.facets_begin(), *id_itor);
		indexOfIntersectedFacet.push_back(index);
	}	

	// ������ facet���� �����߽� ���
	Point_3 centerPt;
	std::vector<float> distanceToFacet;
	Polyhedron::Facet_iterator facet_itor;
	Polyhedron::Halfedge_around_facet_circulator facet_cir;		

	for(int i = 0; i < indexOfIntersectedFacet.size(); i++)
	{
		facet_itor = polyhedron.facets_begin();
		std::advance(facet_itor, indexOfIntersectedFacet[i]);

		centerPt = CalcCenterOfFacet(
			facet_itor->halfedge()->vertex()->point(),
			facet_itor->halfedge()->next()->vertex()->point(),
			facet_itor->halfedge()->next()->next()->vertex()->point());

		distanceToFacet.push_back(CalcSquaredDistance(startPt, centerPt));
	}

	// ���� ����� �Ÿ��� �ִ� facet ã��
	const int index = std::distance(distanceToFacet.begin(), 
		min_element(distanceToFacet.begin(), distanceToFacet.end()));
	printf("%d�� facet ���õ�\n", indexOfIntersectedFacet[index]);

	facet_itor = polyhedron.facets_begin();
	std::advance(facet_itor, indexOfIntersectedFacet[index]);
	return facet_itor;
}

//-------------------------------------------------------------------------------------------------------------------------------
// ������
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::FrameRender(float fElapsedTime)
{	
	if(m_pMesh == NULL) return;
	HRESULT hr;
	D3DXMATRIX mInverse; 
	D3DXVECTOR4 vLightDir;

	// Solid�� �׸���
	V_(m_pEffect->SetTechnique("Tech_RenderScene"));
	V_(m_pEffect->Begin(NULL, 0));	
	V_(m_pEffect->BeginPass(0));

	m_pD3DDevice->SetRenderState( D3DRS_SLOPESCALEDEPTHBIAS, F2DW(0.0f) );
	m_pD3DDevice->SetRenderState(D3DRS_DEPTHBIAS, F2DW(0.0f));	

	D3DXMATRIX mWorldView		= m_pMesh->GetWolrdMtx() * m_mCameraView;		
	D3DXMATRIX mWorldViewProj	= mWorldView * m_mCameraProj;	
	D3DXVECTOR4 vLightPos		= D3DXVECTOR4(-0.577f, -0.577f, -0.577f, 0.f);
	D3DXMatrixInverse(&mInverse, NULL, &(m_pMesh->GetWolrdMtx()));
	D3DXVec4Transform(&vLightDir, &vLightPos, &mInverse);
	D3DXVec3Normalize((D3DXVECTOR3*)&vLightDir, (D3DXVECTOR3*)&vLightDir);
	V_(m_pEffect->SetMatrix("mWorldView",		&mWorldView));
	V_(m_pEffect->SetMatrix("mWorldViewProj",	&mWorldViewProj));
	V_(m_pEffect->SetVector("vLightDir",			&vLightDir));
	V_(m_pEffect->CommitChanges());
	m_pMesh->Render();		

	V_(m_pEffect->EndPass());
	V_(m_pEffect->End()); 

	// Wireframe���� �׸���
	if(m_bSolid) return;

	V_(m_pEffect->Begin(NULL, 0));	
	V_(m_pEffect->BeginPass(1));	

	m_pD3DDevice->SetRenderState( D3DRS_SLOPESCALEDEPTHBIAS, F2DW(-0.000001f) );
	m_pD3DDevice->SetRenderState(D3DRS_DEPTHBIAS, F2DW(-0.000001f));

	mWorldView		= m_pMesh->GetWolrdMtx() * m_mCameraView;			
	mWorldViewProj	= mWorldView * m_mCameraProj;
	V_(m_pEffect->SetMatrix("mWorldView",	&mWorldView));
	V_(m_pEffect->SetMatrix("mWorldViewProj", &mWorldViewProj));
	V_(m_pEffect->CommitChanges());
	m_pMesh->Render();		

	V_(m_pEffect->EndPass());
	V_(m_pEffect->End());

		// Split 2D���� �׸���
	if(m_bSplitNow && m_bPickStartPt)	
		DrawLineSement(m_LineStartX, m_LineStartY, m_LineEndX, m_LineEndY);	
}

//-------------------------------------------------------------------------------------------------------------------------------
// �� �����Ӹ��� ������Ʈ �ؾ��� ��
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::FrameMove(float fElapsedTime)
{
	m_Camera.FrameMove(fElapsedTime);

	m_mCameraView = *(m_Camera.GetViewMatrix());
	m_mCameraProj = *(m_Camera.GetProjMatrix());
}

//-------------------------------------------------------------------------------------------------------------------------------
// �¾�
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::SetUp(void)
{
	m_pEffect	= NULL;
	m_pMesh		= NULL;
	m_bSolid	= false;
	m_bSplitNow	= false;
	m_bPickStartPt = false;

	m_LineStartX = 0;
	m_LineStartY = 0;
	m_LineEndX = 0;
	m_LineEndY = 0;

	D3DXMatrixIdentity(&m_mCameraView);
	D3DXMatrixIdentity(&m_mCameraProj);

	LoadEffectFromFile();
	SetUpCamera();
	SetUpLine();
}

//-------------------------------------------------------------------------------------------------------------------------------
// ����Ʈ ���� �ε�
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::LoadEffectFromFile(void)
{
	DWORD dwShaderFlags = D3DXFX_NOT_CLONEABLE | D3DXSHADER_ENABLE_BACKWARDS_COMPATIBILITY;
#ifdef DEBUG_VS
	dwShaderFlags |= D3DXSHADER_FORCE_VS_SOFTWARE_NOOPT;
#endif
#ifdef DEBUG_PS
	dwShaderFlags |= D3DXSHADER_FORCE_PS_SOFTWARE_NOOPT;
#endif

	LPD3DXBUFFER erBuf = NULL;
	HRESULT hr = D3DXCreateEffectFromFile(
		m_pD3DDevice, L"Shaders//Effect.fx", NULL, NULL, dwShaderFlags, NULL, &m_pEffect, &erBuf);

	if(erBuf != NULL)
	{
		MessageBoxA(DXUTGetHWND(), (char*)erBuf->GetBufferPointer(), "ERROR!", 0);
	}
}

//-------------------------------------------------------------------------------------------------------------------------------
// ī�޶� �¾�
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::SetUpCamera(void)
{
	D3DXVECTOR3	vFromPt, vLookatPt;
	float fov		= D3DX_PI/4;
	float aspect	= WINDOW_SIZE_W / (FLOAT)WINDOW_SIZE_H;
	float nearPlane = 0.1f;
	float farPlane	= 5000.f;

	vFromPt		= D3DXVECTOR3(0.f, 0.f, -500.f);
	vLookatPt	= D3DXVECTOR3(0.f, 0.f, 0.f);
	m_Camera.SetViewParams(&vFromPt, &vLookatPt);
	m_Camera.SetProjParams(fov, aspect, nearPlane, farPlane);	

	m_Camera.SetWindow( WINDOW_SIZE_W, WINDOW_SIZE_H );
	m_Camera.SetButtonMasks( NULL, MOUSE_WHEEL, MOUSE_RIGHT_BUTTON );	
}

//-------------------------------------------------------------------------------------------------------------------------------
// Split�� 2D ���� �¾�
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::SetUpLine(void)
{
	D3DXCreateLine(m_pD3DDevice, &m_pLine);
	m_pLine->SetWidth(4);
}

//-------------------------------------------------------------------------------------------------------------------------------
// �޸� ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::Release(void)
{
	SAFE_DELETE(m_pMesh);

	SAFE_RELEASE(m_pEffect);

	SAFE_RELEASE(m_pLine);

	m_pD3DDevice->SetTexture(0, NULL);
}

//-------------------------------------------------------------------------------------------------------------------------------
// ��ũ���� ����
//-------------------------------------------------------------------------------------------------------------------------------
void CManager::CaptureScene(void)
{
	HRESULT hr;
	SYSTEMTIME timer;
	GetLocalTime(&timer);

	WCHAR filename[256] = {};
	wsprintf(filename, L"Capture\\%04d��_%02d��%02d��_%02d��%02d��%02d��.png",
		timer.wYear, timer.wMonth, timer.wDay, timer.wHour, timer.wMinute, timer.wSecond);

	LPDIRECT3DSURFACE9 pBackBuffer = NULL;
	m_pD3DDevice->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &pBackBuffer);
	D3DXSaveSurfaceToFile(filename, D3DXIFF_PNG, pBackBuffer, NULL, NULL);
	pBackBuffer->Release();
}

//-------------------------------------------------------------------------------------------------------------------------------
// ������
//-------------------------------------------------------------------------------------------------------------------------------
CManager::CManager(LPDIRECT3DDEVICE9 pD3DDevice)
:m_pD3DDevice(pD3DDevice)
{	
	SetUp();
}

//-------------------------------------------------------------------------------------------------------------------------------
// �Ҹ���
//-------------------------------------------------------------------------------------------------------------------------------
CManager::~CManager(void)
{
	Release();
}

//-------------------------------------------------------------------------------------------------------------------------------
// �ﰢ�� ���� �߽� ���
//-------------------------------------------------------------------------------------------------------------------------------
Point_3 CManager::CalcCenterOfFacet(Point_3& p1, Point_3& p2, Point_3& p3) {
	return Point_3(
		(p1.x()+p2.x()+p3.x())/3.f, 
		(p1.y()+p2.y()+p3.y())/3.f,
		(p1.z()+p2.z()+p3.z())/3.f);		
}

//-------------------------------------------------------------------------------------------------------------------------------
// ���콺 Ŀ�� ��ġ ���ϱ�
//-------------------------------------------------------------------------------------------------------------------------------
POINT CManager::GetCursorPosInClient(void) {
	POINT ptCursor;
	GetCursorPos( &ptCursor );
	ScreenToClient( DXUTGetHWND(), &ptCursor );
	return ptCursor;
}