#include "DXUT.h"
#include "Segments.h"

CSegments::CSegments()
{

}
CSegments::~CSegments()
{
	m_SegmentVector.clear();
}

int CSegments::addSegment(CSegment* pSegment)
{
	m_SegmentVector.push_back(pSegment);
	return m_SegmentVector.size();
}
int CSegments::size()
{
	return m_SegmentVector.size();
}

void CSegments::setVisited(boolean bVisit)
{
	std::vector< CSegment*>::iterator fit = m_SegmentVector.begin();
	for(; fit != m_SegmentVector.end(); fit++)
		(*fit)->setVisited(bVisit);
}