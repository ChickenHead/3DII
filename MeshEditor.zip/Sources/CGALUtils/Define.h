﻿#pragma once

// boost
#include "..\include\boost\fusion\container\map.hpp"
#include "..\include\boost\fusion\include\map.hpp"
#include "..\include\boost\fusion\container\map\map_fwd.hpp"
#include "..\include\boost\fusion\include\map_fwd.hpp"
#include "..\include\boost\tuple\tuple.hpp"

// CGAL
#include "..\include\boost\tuple\tuple.hpp"
#include "..\include\CGAL\Simple_cartesian.h"
#include "..\include\CGAL\Polyhedron_3.h"

// Simplification
#include "..\include\CGAL\Surface_mesh_simplification\HalfedgeGraph_Polyhedron_3.h"
#include "..\include\CGAL\Surface_mesh_simplification\edge_collapse.h"
#include "..\include\CGAL\Surface_mesh_simplification\Policies\Edge_collapse\Midpoint_placement.h"
#include "..\include\CGAL\Surface_mesh_simplification\Policies\Edge_collapse\Constrained_placement.h"
#include "..\include\CGAL\Surface_mesh_simplification\Policies\Edge_collapse\Count_ratio_stop_predicate.h"
namespace SMS = CGAL::Surface_mesh_simplification ;

// AABB
#include "..\include\CGAL\AABB_tree.h"
#include "..\include\CGAL\AABB_traits.h"
#include "..\include\CGAL\AABB_face_graph_triangle_primitive.h"

#include "cglab_facet.h"

// tydef
typedef CGAL::Simple_cartesian<double>							Kernel;
typedef CGAL::Polyhedron_3<Kernel, CGLab_items>					Polyhedron;
typedef CGAL::AABB_face_graph_triangle_primitive<Polyhedron>	Primitive;
typedef CGAL::AABB_traits<Kernel, Primitive>					Traits;
typedef CGAL::AABB_tree<Traits>									Tree;

typedef Polyhedron::Facet_iterator	Facet_iterator;
typedef Polyhedron::Vertex_iterator Vertex_iterator;
typedef Polyhedron::Face_handle		Face_handle;

typedef Kernel::Point_3			Point_3;
typedef Kernel::Vector_3		Vector_3;
typedef Kernel::Plane_3			Plane_3;
typedef Kernel::Iso_cuboid_3	Iso_cuboid_3;
typedef Kernel::Triangle_3		Triangle_3;
typedef Kernel::Line_3			Line_3;
typedef Kernel::FT				FT;
typedef Kernel::Plane_3			Plane_3;
typedef Kernel::Segment_3		Segment_3;

typedef Tree::Primitive_id		Primitive_id;

typedef boost::optional< Tree::Intersection_and_primitive_id<Segment_3>::Type >		Segment_intersection;
typedef boost::optional< Tree::Intersection_and_primitive_id<Plane_3>::Type >		Plane_intersection;