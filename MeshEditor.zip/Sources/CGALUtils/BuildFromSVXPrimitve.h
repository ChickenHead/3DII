#pragma once
#include <CGAL/Polyhedron_incremental_builder_3.h>

typedef unsigned int uint;

template <class HDS>
class BuildFromSVXPrimitve : public CGAL::Modifier_base<HDS> 
{
private:
	const std::vector<Point_3>& _vertices;
	const std::vector<boost::tuple<int,int,int>> _facets;

public:
	BuildFromSVXPrimitve(const std::vector<Point_3>& vertices, 
		const std::vector<boost::tuple<int, int, int>>& facets)
		: _vertices(vertices), _facets(facets)
	{ }

	void operator()(HDS& hds)
	{
		CGAL::Polyhedron_incremental_builder_3<HDS> B(hds, true);

		B.begin_surface(_vertices.size(), _facets.size(), 0);

		// vertex �߰�	
		for(uint i = 0; i < _vertices.size(); i++)
			B.add_vertex(_vertices[i]);

		// face �߰�	
		for(uint i = 0; i < _facets.size(); i++)
		{
			B.begin_facet();
			B.add_vertex_to_facet(_facets[i].template get<0>());
			B.add_vertex_to_facet(_facets[i].template get<1>());
			B.add_vertex_to_facet(_facets[i].template get<2>());
			B.end_facet();
		}

		B.end_surface();
	}
};