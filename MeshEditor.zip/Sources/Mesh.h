#pragma once
#include "CGALUtils/Define.h"
#include "CGALUtils/BuildFromSVXPrimitve.h"
#include "../include/CGAL/Polyhedron_incremental_builder_3.h"
#include "../include/CGAL/IO/Polyhedron_iostream.h"

//Segment
#include "Segment.h"
#include "Segments.h"

// assimp
#include <cimport.h>
#include <scene.h>

//hash_map
#include <hash_map>
#include <unordered_map>

//file stream
#include <fstream>

struct Border_is_constrained_edge_map{
  const Polyhedron* sm_ptr;
  typedef boost::graph_traits<Polyhedron>::edge_descriptor key_type;
  typedef bool value_type;
  typedef value_type reference;
  typedef boost::readable_property_map_tag category;

  Border_is_constrained_edge_map()
  {}

  Border_is_constrained_edge_map(const Polyhedron& sm)
    : sm_ptr(&sm)
  {}

  friend bool get(Border_is_constrained_edge_map m, const key_type& edge) {
    return CGAL::is_border(edge, *m.sm_ptr);
  }
};

//
// Placement class
//
typedef SMS::Constrained_placement<SMS::Midpoint_placement<Polyhedron>,
                                   Border_is_constrained_edge_map > Placement;


class CMesh
{
private:
	LPDIRECT3DDEVICE9		m_pD3DDevice;
	char*					m_pFilePath;

	LPDIRECT3DVERTEXBUFFER9 m_pVertexBuffer;	

	// Matrix
	D3DXMATRIX				m_mScale;
	D3DXMATRIX				m_mRotation;
	D3DXMATRIX				m_mTranslation;
	D3DXMATRIX				m_mWorld;

	Polyhedron				m_Polyhedron;

	CSegments*				m_pSegments;
	CSegments*				m_pSelectedSegments;

	static const unsigned long m_SelectedSegmentColor = 0xffff0000;

public:
	HRESULT					InitVertexBuffer(void);

private:	
	void GeneratePolyhedronFromFile(void);
	void autoSegmentation(float);
	void mergeSegment(void);
	void splitWithLineSegment(Point_3, Point_3, Point_3);
	void flattenSegment(void);
	/*void segmentAroundAFacet(CSegment * pSegment, 
		const Polyhedron::Halfedge_around_facet_circulator facet_circulator, 
		double threshold, D3DXVECTOR3 average_normal, int call_depth, unsigned long facetColor, int segmentID);
		*/
	void segmentAroundAFacet(
		const Polyhedron::Halfedge_around_facet_circulator facet_circulator, 
		int call_depth);
	void resetVisit();
	unsigned long createColor(void);
	unsigned long createColor(int r, int g, int b);

public:
	CMesh(LPDIRECT3DDEVICE9 pD3DDevice, char* path);
	~CMesh(void);
	
	void Render(void);
	void Init();
	void LoadMesh(void);
	void Segmentation(int);
	void CreateSegments(void);
	void Merge(void);
	void Split(Point_3, Point_3, Point_3);
	void Flatten(void);

	int GetSelectedSegmentId(int id);
	void SelectSegment(int segmentId);

	D3DXMATRIX& GetWolrdMtx(void)	{ return m_mWorld; }
	Polyhedron& GetPolyhedron(void) { return m_Polyhedron; }
};
