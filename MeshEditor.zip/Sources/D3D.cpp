//-------------------------------------------------------------------------------------------------------------------------------
// File: D3D.cpp
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//-------------------------------------------------------------------------------------------------------------------------------
#pragma once
#include "DXUT.h"
#include "DXUTgui.h"
#include "DXUTSettingsDlg.h"
#include "Manager.h"
#include "..\resource.h"

// UI control IDs
#define IDC_RADIO_SOLID				1
#define IDC_RADIO_SOLIDWIREFRAME	2
#define IDC_BUTTON_LOAD				3
#define IDC_BUTTON_SEGMENTATION		4
#define IDC_BUTTON_MERGE			5
#define IDC_BUTTON_SPLIT			6
#define IDC_BUTTON_FLATTEN			7

//-------------------------------------------------------------------------------------------------------------------------------
// Global variables
//-------------------------------------------------------------------------------------------------------------------------------
CDXUTDialogResourceManager  g_DialogResourceManager; // manager for shared resources of dialogs
CD3DSettingsDlg             g_SettingsDlg;          // Device settings dialog
CDXUTTextHelper*            g_pTxtHelper = NULL;
CDXUTDialog                 g_SampleUI;             // dialog for sample specific controls

// Direct3D 9 resources
ID3DXFont*                  g_pFont9 = NULL;
ID3DXSprite*                g_pSprite9 = NULL;

CManager*					g_pManager = NULL;
HINSTANCE					g_hInstance;
int							g_nThreshold;


//-------------------------------------------------------------------------------------------------------------------------------
// Forward declarations 
//-------------------------------------------------------------------------------------------------------------------------------
INT_PTR CALLBACK DialogProcInputThreshold( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
INT_PTR CALLBACK DialogProcNotifySplit( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing,
	void* pUserContext );
void CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext );
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext );
void CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext );
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext );

bool CALLBACK IsD3D9DeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat, D3DFORMAT BackBufferFormat,
	bool bWindowed, void* pUserContext );
HRESULT CALLBACK OnD3D9CreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc,
	void* pUserContext );
HRESULT CALLBACK OnD3D9ResetDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc,
	void* pUserContext );
void CALLBACK OnD3D9FrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext );
void CALLBACK OnD3D9LostDevice( void* pUserContext );
void CALLBACK OnD3D9DestroyDevice( void* pUserContext );

void InitApp();
void RenderText();


//-------------------------------------------------------------------------------------------------------------------------------
// Entry point to the program. Initializes everything and goes into a message processing 
// loop. Idle time is used to render the scene.
//-------------------------------------------------------------------------------------------------------------------------------
int WINAPI wWinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nCmdShow )
{
	// Enable run-time memory check for debug builds.
#if defined(DEBUG) | defined(_DEBUG)
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
#endif

	g_hInstance = hInstance;

	// DXUT will create and use the best device (either D3D9 or D3D10) 
	// that is available on the system depending on which D3D callbacks are set below

	// Set DXUT callbacks
	DXUTSetCallbackMsgProc( MsgProc );
	DXUTSetCallbackKeyboard( OnKeyboard );
	DXUTSetCallbackFrameMove( OnFrameMove );
	DXUTSetCallbackDeviceChanging( ModifyDeviceSettings );

	DXUTSetCallbackD3D9DeviceAcceptable( IsD3D9DeviceAcceptable );
	DXUTSetCallbackD3D9DeviceCreated( OnD3D9CreateDevice );
	DXUTSetCallbackD3D9DeviceReset( OnD3D9ResetDevice );
	DXUTSetCallbackD3D9DeviceLost( OnD3D9LostDevice );
	DXUTSetCallbackD3D9DeviceDestroyed( OnD3D9DestroyDevice );
	DXUTSetCallbackD3D9FrameRender( OnD3D9FrameRender );

	InitApp();
	DXUTInit( true, true, NULL ); // Parse the command line, show msgboxes on error, no extra command line params
	DXUTSetCursorSettings( true, true );
	DXUTCreateWindow( L"Mesh Editor" );
	DXUTCreateDevice( true, WINDOW_SIZE_W, WINDOW_SIZE_H );
	DXUTMainLoop(); // Enter into the DXUT render loop

	return DXUTGetExitCode();
}


//-------------------------------------------------------------------------------------------------------------------------------
// Initialize the app 
//-------------------------------------------------------------------------------------------------------------------------------
void InitApp()
{
	g_SettingsDlg.Init( &g_DialogResourceManager );	
	g_SampleUI.Init( &g_DialogResourceManager );

	g_SampleUI.SetCallback( OnGUIEvent ); 	

	g_SampleUI.AddRadioButton( IDC_RADIO_SOLID, 1, L"Solid", 0, 0, 240, 30, false );
	g_SampleUI.AddRadioButton( IDC_RADIO_SOLIDWIREFRAME, 1, L"Solid + WireFrame", 0, 30, 240, 30, true );
	g_SampleUI.AddButton( IDC_BUTTON_LOAD, L"Load Mesh", 0, 80, 100, 40 );
	g_SampleUI.AddButton( IDC_BUTTON_SEGMENTATION, L"Auto Segmentation", 0, 130, 100, 40 );
	g_SampleUI.AddButton( IDC_BUTTON_MERGE, L"Merge", 0, 180, 100, 40 );
	g_SampleUI.AddButton( IDC_BUTTON_SPLIT, L"Split", 0, 230, 100, 40 );
	g_SampleUI.AddButton( IDC_BUTTON_FLATTEN, L"Flatten", 0, 280, 100, 40 );
}


//-------------------------------------------------------------------------------------------------------------------------------
// Render the help and statistics text. This function uses the ID3DXFont interface for 
// efficient text rendering.
//-------------------------------------------------------------------------------------------------------------------------------
void RenderText()
{
	g_pTxtHelper->Begin();
	g_pTxtHelper->SetInsertionPos( 5, 5 );
	g_pTxtHelper->SetForegroundColor( D3DXCOLOR( 1.0f, 1.0f, 0.0f, 1.0f ) );
	g_pTxtHelper->DrawTextLine( DXUTGetFrameStats( DXUTIsVsyncEnabled() ) );
	g_pTxtHelper->DrawTextLine( DXUTGetDeviceStats() );
	g_pManager->DrawText(g_pTxtHelper);
	g_pTxtHelper->End();
}


//-------------------------------------------------------------------------------------------------------------------------------
// Rejects any D3D9 devices that aren't acceptable to the app by returning false
//-------------------------------------------------------------------------------------------------------------------------------
bool CALLBACK IsD3D9DeviceAcceptable( D3DCAPS9* pCaps, D3DFORMAT AdapterFormat,
	D3DFORMAT BackBufferFormat, bool bWindowed, void* pUserContext )
{
	// Skip backbuffer formats that don't support alpha blending
	IDirect3D9* pD3D = DXUTGetD3D9Object();
	if( FAILED( pD3D->CheckDeviceFormat( pCaps->AdapterOrdinal, pCaps->DeviceType,
		AdapterFormat, D3DUSAGE_QUERY_POSTPIXELSHADER_BLENDING,
		D3DRTYPE_TEXTURE, BackBufferFormat ) ) )
		return false;

	// No fallback defined by this app, so reject any device that 
	// doesn't support at least ps2.0
	if( pCaps->PixelShaderVersion < D3DPS_VERSION( 2, 0 ) )
		return false;

	return true;
}


//-------------------------------------------------------------------------------------------------------------------------------
// Called right before creating a D3D9 or D3D10 device, allowing the app to modify the device settings as needed
//-------------------------------------------------------------------------------------------------------------------------------
bool CALLBACK ModifyDeviceSettings( DXUTDeviceSettings* pDeviceSettings, void* pUserContext )
{
	if( pDeviceSettings->ver == DXUT_D3D9_DEVICE )
	{
		IDirect3D9* pD3D = DXUTGetD3D9Object();
		D3DCAPS9 Caps;
		pD3D->GetDeviceCaps( pDeviceSettings->d3d9.AdapterOrdinal, pDeviceSettings->d3d9.DeviceType, &Caps );

		// Turn vsync off
		pDeviceSettings->d3d9.pp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;		
		//g_SettingsDlg.GetDialogControl()->GetComboBox( DXUTSETTINGSDLG_PRESENT_INTERVAL )->SetEnabled( false );

		// If device doesn't support HW T&L or doesn't support 1.1 vertex shaders in HW 
		// then switch to SWVP.
		if( ( Caps.DevCaps & D3DDEVCAPS_HWTRANSFORMANDLIGHT ) == 0 ||
			Caps.VertexShaderVersion < D3DVS_VERSION( 1, 1 ) )
		{
			pDeviceSettings->d3d9.BehaviorFlags = D3DCREATE_SOFTWARE_VERTEXPROCESSING;
		}

		// Debugging vertex shaders requires either REF or software vertex processing 
		// and debugging pixel shaders requires REF.  
#ifdef DEBUG_VS
		if( pDeviceSettings->d3d9.DeviceType != D3DDEVTYPE_REF )
		{
			pDeviceSettings->d3d9.BehaviorFlags &= ~D3DCREATE_HARDWARE_VERTEXPROCESSING;
			pDeviceSettings->d3d9.BehaviorFlags &= ~D3DCREATE_PUREDEVICE;
			pDeviceSettings->d3d9.BehaviorFlags |= D3DCREATE_SOFTWARE_VERTEXPROCESSING;
		}
#endif
#ifdef DEBUG_PS
		pDeviceSettings->d3d9.DeviceType = D3DDEVTYPE_REF;
#endif
	}

	// For the first device created if its a REF device, optionally display a warning dialog box
	static bool s_bFirstTime = true;
	if( s_bFirstTime )
	{
		s_bFirstTime = false;
		if( ( DXUT_D3D9_DEVICE == pDeviceSettings->ver && pDeviceSettings->d3d9.DeviceType == D3DDEVTYPE_REF ) ||
			( DXUT_D3D10_DEVICE == pDeviceSettings->ver &&
			pDeviceSettings->d3d10.DriverType == D3D10_DRIVER_TYPE_REFERENCE ) )
			DXUTDisplaySwitchingToREFWarning( pDeviceSettings->ver );
	}

	return true;
}


//-------------------------------------------------------------------------------------------------------------------------------
// Create any D3D9 resources that will live through a device reset (D3DPOOL_MANAGED)
// and aren't tied to the back buffer size
//-------------------------------------------------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D9CreateDevice( IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc,
	void* pUserContext )
{
	HRESULT hr;

	AllocConsole();
	freopen("CONOUT$", "a", stderr);
	freopen("CONOUT$", "a", stdout);
	freopen("CONIN$", "r", stdin);

	V_RETURN( g_DialogResourceManager.OnD3D9CreateDevice( pd3dDevice ) );
	V_RETURN( g_SettingsDlg.OnD3D9CreateDevice( pd3dDevice ) );

	V_RETURN( D3DXCreateFont( pd3dDevice, 15, 0, FW_BOLD, 1, FALSE, DEFAULT_CHARSET,
		OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
		L"Arial", &g_pFont9 ) )

	g_pManager = new CManager(pd3dDevice);

	return S_OK;
}


//-------------------------------------------------------------------------------------------------------------------------------
// Create any D3D9 resources that won't live through a device reset (D3DPOOL_DEFAULT) 
// or that are tied to the back buffer size 
//-------------------------------------------------------------------------------------------------------------------------------
HRESULT CALLBACK OnD3D9ResetDevice( IDirect3DDevice9* pd3dDevice,
	const D3DSURFACE_DESC* pBackBufferSurfaceDesc, void* pUserContext )
{
	HRESULT hr;

	V_RETURN( g_DialogResourceManager.OnD3D9ResetDevice() );
	V_RETURN( g_SettingsDlg.OnD3D9ResetDevice() );

	if( g_pFont9 ) V_RETURN( g_pFont9->OnResetDevice() );

	V_RETURN( D3DXCreateSprite( pd3dDevice, &g_pSprite9 ) );
	g_pTxtHelper = new CDXUTTextHelper( g_pFont9, g_pSprite9, NULL, NULL, 15 );

	g_SampleUI.SetLocation( pBackBufferSurfaceDesc->Width - 170, 10 );
	g_SampleUI.SetSize( 170, 300 );

	return S_OK;
}


//-------------------------------------------------------------------------------------------------------------------------------
// Handle updates to the scene.  This is called regardless of which D3D API is used
//-------------------------------------------------------------------------------------------------------------------------------
void CALLBACK OnFrameMove( double fTime, float fElapsedTime, void* pUserContext )
{
	g_pManager->FrameMove(fElapsedTime);
}


//-------------------------------------------------------------------------------------------------------------------------------
// Render the scene using the D3D9 device
//-------------------------------------------------------------------------------------------------------------------------------
void CALLBACK OnD3D9FrameRender( IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext )
{
	HRESULT hr;

	// If the settings dialog is being shown, then render it instead of rendering the app's scene
	if( g_SettingsDlg.IsActive() )
	{
		g_SettingsDlg.OnRender( fElapsedTime );
		return;
	}

	// Clear the render target and the zbuffer 
	V_( pd3dDevice->Clear( 0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB( 0, 45, 50, 170 ), 1.0f, 0 ) );

	// Render the scene
	if( SUCCEEDED( pd3dDevice->BeginScene() ) )
	{
		g_pManager->FrameRender(fElapsedTime);		
		RenderText();		
		V_( g_SampleUI.OnRender( fElapsedTime ) );

		V_( pd3dDevice->EndScene() );
	}
}


//-------------------------------------------------------------------------------------------------------------------------------
// Handle messages to the application
//-------------------------------------------------------------------------------------------------------------------------------
LRESULT CALLBACK MsgProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam, bool* pbNoFurtherProcessing,
	void* pUserContext )
{
	// Pass messages to dialog resource manager calls so GUI state is updated correctly
	*pbNoFurtherProcessing = g_DialogResourceManager.MsgProc( hWnd, uMsg, wParam, lParam );
	if( *pbNoFurtherProcessing )
		return 0;

	// Pass messages to settings dialog if its active
	if( g_SettingsDlg.IsActive() )
	{
		g_SettingsDlg.MsgProc( hWnd, uMsg, wParam, lParam );
		return 0;
	}

	// Give the dialogs a chance to handle the message first
	*pbNoFurtherProcessing = g_SampleUI.MsgProc( hWnd, uMsg, wParam, lParam );
	if( *pbNoFurtherProcessing )
		return 0;

	// Pass all remaining windows messages to camera so it can respond to user input
	if(g_pManager)
	{
		switch(uMsg)
		{
		case WM_LBUTTONDOWN:	
			g_pManager->OnLButtonDown();
			break;
		case WM_LBUTTONUP:
			g_pManager->OnLButtonUp();
			break;
		case WM_MOUSEMOVE:
			g_pManager->OnMouseMove();
			break;
		}

		g_pManager->MsgProc(hWnd, uMsg, wParam, lParam);
	}

	return 0;
}


//-------------------------------------------------------------------------------------------------------------------------------
// threshold �Է� ���̾�α�
//-------------------------------------------------------------------------------------------------------------------------------
INT_PTR CALLBACK DialogProcInputThreshold(HWND hDlg, UINT uMsg, WPARAM wParam,LPARAM lParam)
{	
	int x, y;
	RECT rect;	

	switch(uMsg) 
	{
	case WM_INITDIALOG:		
		GetClientRect(hDlg, &rect);
		x=::GetSystemMetrics(SM_CXSCREEN);
		y=::GetSystemMetrics(SM_CYSCREEN);
		x=(x-rect.right)/2; 
		y=(y-rect.bottom)/2; 
		MoveWindow(hDlg, x, y, rect.right+7, rect.bottom+25, TRUE); 
		SetDlgItemText(hDlg, IDC_STR1, L"threshlod: ");
		SetDlgItemInt(hDlg, IDC_EDIT1, 40, TRUE);
		return TRUE;
		break;
	case WM_COMMAND:		
		switch(wParam)
		{
		case IDC_OK:
			g_nThreshold = GetDlgItemInt(hDlg, IDC_EDIT1, NULL, TRUE);			
			EndDialog(hDlg, IDOK);
			return TRUE;
			break;
		case IDC_CANCEL:
			EndDialog(hDlg, IDCANCEL);
			return FALSE;
			break;
		}
		break;
	}
	return FALSE;
}

//-------------------------------------------------------------------------------------------------------------------------------
// Split Ȯ�� ���̾�α�
//-------------------------------------------------------------------------------------------------------------------------------
INT_PTR CALLBACK DialogProcNotifySplit(HWND hDlg, UINT uMsg, WPARAM wParam,LPARAM lParam)
{	
	int x, y;
	RECT rect;	

	switch(uMsg) 
	{
	case WM_INITDIALOG:		
		GetClientRect(hDlg, &rect);
		x=::GetSystemMetrics(SM_CXSCREEN);
		y=::GetSystemMetrics(SM_CYSCREEN);
		x=(x-rect.right)/2; 
		y=(y-rect.bottom)/2; 
		MoveWindow(hDlg, x, y, rect.right+7, rect.bottom+25, TRUE); 
		return TRUE;
		break;
	case WM_COMMAND:		
		switch(wParam)
		{
		case IDC_OK:			
			EndDialog(hDlg, IDOK);
			return TRUE;
			break;
		case IDC_CANCEL:
			EndDialog(hDlg, IDCANCEL);
			return FALSE;
			break;
		}
		break;
	}
	return FALSE;
}


//-------------------------------------------------------------------------------------------------------------------------------
// Handle key presses
//-------------------------------------------------------------------------------------------------------------------------------
void CALLBACK OnKeyboard( UINT nChar, bool bKeyDown, bool bAltDown, void* pUserContext )
{
	if(bKeyDown)
		g_pManager->OnKeyboard(nChar);
}


//-------------------------------------------------------------------------------------------------------------------------------
// Handles the GUI events
//-------------------------------------------------------------------------------------------------------------------------------
void CALLBACK OnGUIEvent( UINT nEvent, int nControlID, CDXUTControl* pControl, void* pUserContext )
{
	switch( nControlID )
	{
	case IDC_BUTTON_LOAD:
			g_pManager->OnLoadMesh();
		break;
	case IDC_BUTTON_SEGMENTATION:
			if(DialogBox(g_hInstance, MAKEINTRESOURCE(IDD_DIALOG1), 
				DXUTGetHWND(), DialogProcInputThreshold) == TRUE)	
				g_pManager->OnAutoSegmentation(g_nThreshold);
		break;
	case IDC_RADIO_SOLID:
		g_pManager->OnSolidMode();
		break;
	case IDC_RADIO_SOLIDWIREFRAME:
		g_pManager->OnSolidWireFrameMode();
		break;
	case IDC_BUTTON_MERGE:
		g_pManager->OnMerge();
		break;
	case IDC_BUTTON_SPLIT:
		g_pManager->OnSplit();
		if(DialogBox(g_hInstance, MAKEINTRESOURCE(IDD_DIALOG2), 
			DXUTGetHWND(), DialogProcNotifySplit) == TRUE) {}
		break;
	case IDC_BUTTON_FLATTEN:
		g_pManager->OnFlattenSegment();
		break;
	}
}


//-------------------------------------------------------------------------------------------------------------------------------
// Release D3D9 resources created in the OnD3D9ResetDevice callback 
//-------------------------------------------------------------------------------------------------------------------------------
void CALLBACK OnD3D9LostDevice( void* pUserContext )
{
	g_DialogResourceManager.OnD3D9LostDevice();
	g_SettingsDlg.OnD3D9LostDevice();
	if( g_pFont9 ) g_pFont9->OnLostDevice();	
	SAFE_RELEASE( g_pSprite9 );
	SAFE_DELETE( g_pTxtHelper );
}


//-------------------------------------------------------------------------------------------------------------------------------
// Release D3D9 resources created in the OnD3D9CreateDevice callback 
//-------------------------------------------------------------------------------------------------------------------------------
void CALLBACK OnD3D9DestroyDevice( void* pUserContext )
{
	FreeConsole();
	g_DialogResourceManager.OnD3D9DestroyDevice();
	g_SettingsDlg.OnD3D9DestroyDevice();	
	SAFE_RELEASE( g_pFont9 );

	SAFE_DELETE(g_pManager);
}


