#include "DXUT.h"
#include "Segment.h"

/*
void CSegment::setFacet_vector(std::vector<Polyhedron::Polyhedron_3> facet)
{
	m_Facet_vector.push_back(facet);
}
void CSegment::setVertex_vector(std::vector<Polyhedron::Vertex_handle> vertex)
{
	m_Vertex_vector = vertex;
}
*/
CSegment::CSegment()
{
	bSelected = false;
}
CSegment::~CSegment(void)
{
	m_Facet_vector.clear();
	m_Vertex_vector.clear();
}

int CSegment::addFacet(Polyhedron::Facet_handle facet)
{
	m_Facet_vector.push_back(facet);
	return 0;
}

int CSegment::size()
{
	return m_Facet_vector.size();
}

int CSegment::generateVertexVectorFromFacetsVector()
{
	Polyhedron::Facet_handle facet_h;
	Polyhedron::Vertex_handle vertex_h1;
	Polyhedron::Vertex_handle vertex_h2;
	Polyhedron::Vertex_handle vertex_h3;

	m_Vertex_vector.clear();
	
	std::map<Polyhedron::Vertex_handle, int> vertex_map;

	int vertex_index = 0;
	std::vector<Polyhedron::Facet_handle>::const_iterator cit1 = m_Facet_vector.cbegin();
    for (; cit1 != m_Facet_vector.cend(); ++cit1) 
	{
		facet_h = (*cit1);
		vertex_h1 = facet_h->halfedge()->vertex();
		vertex_h2 = facet_h->halfedge()->next()->vertex();
		vertex_h3 = facet_h->halfedge()->next()->next()->vertex();
		
		
		if(vertex_map.find(vertex_h1) == vertex_map.end())
		{
			vertex_map[vertex_h1] = vertex_index++;
			m_Vertex_vector.push_back(vertex_h1);
		}
		if(vertex_map.find(vertex_h2) == vertex_map.end())
		{
			vertex_map[vertex_h2] = vertex_index++;
			m_Vertex_vector.push_back(vertex_h2);
		}
		if(vertex_map.find(vertex_h3) == vertex_map.end())
		{
			vertex_map[vertex_h3] = vertex_index++;
			m_Vertex_vector.push_back(vertex_h3);
		}
	}
	
	return 0;
}


void CSegment::setVisited(boolean bVisit)
{
	std::vector<Polyhedron::Facet_handle>::iterator fit = 	m_Facet_vector.begin();
	
	for(; fit != m_Facet_vector.end(); fit++)
		(*fit)->setVisited(bVisit);
}
void CSegment::setSegmentID(int id)
{
	nSegmentID = id;
}
int CSegment::getSegmentID()
{
	return nSegmentID;
}
void CSegment::setSegmentColor(unsigned long color)
{
	nSegmentColor = color;
	updateFacetColor(nSegmentColor);	

}
void CSegment::updateFacetColor(unsigned long color)
{
	std::vector<Polyhedron::Facet_handle>::iterator fit = 	m_Facet_vector.begin();
	for(; fit != m_Facet_vector.end(); fit++)
		(*fit)->setFacetColor(color);
}