#include "DXUT.h"
#include "Mesh.h"

struct CUSTOMVERTEX
{
	D3DXVECTOR3	position;
	D3DXVECTOR3 normal;
	DWORD		color;
};

#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE)
#define MAX_CALL_DEPTH 1024
#define THRESHOLD 0.0000001

std::vector<Polyhedron::Facet_handle> facet_vector;
std::vector<Polyhedron::Vertex_handle> vertex_vector;

	
//-------------------------------------------------------------------------------------------------------------------------------
// �޽� �ε���
//-------------------------------------------------------------------------------------------------------------------------------
	
void CMesh::LoadMesh(void)
{
	GeneratePolyhedronFromFile();
	InitVertexBuffer();	
}

void CMesh::CreateSegments()
{
	m_pSegments = new CSegments();
	
	m_pSelectedSegments = new CSegments();
}
void CMesh::Segmentation(int angle)
{
	float threshold = cos(angle * (3.14 / 180.0));

	//���õ� Segment�� ���ٸ� ��ü Segment�� ���� Segmentation ����
	if(m_pSelectedSegments->size() == 0){
		m_pSegments->setVisited(false);
		autoSegmentation(threshold);
	}
	//���õ� Segment�� �ִٸ� ���õ� Segment�� ���ؼ� Segmentation ����
	else
	{
		m_pSegments->setVisited(true);
		m_pSelectedSegments->setVisited(false);
		autoSegmentation(threshold);
	}
	
	InitVertexBuffer();
}
//-------------------------------------------------------------------------------------------------------------------------------
// file�κ��� Polyhedron ����
//-------------------------------------------------------------------------------------------------------------------------------
void CMesh::GeneratePolyhedronFromFile(void)
{
	printf("Polyhedron ���� ����\n");
	
	const struct aiScene* scene = aiImportFile(m_pFilePath, 0);	
	const struct aiMesh* mesh = scene->mMeshes[scene->mRootNode->mMeshes[0]];

	// vertex list ����
	std::vector<D3DXVECTOR3> f3Vertices;
	for(int i = 0; i < mesh->mNumVertices; i++)
	{
		f3Vertices.push_back(D3DXVECTOR3(mesh->mVertices[i].x, mesh->mVertices[i].y, mesh->mVertices[i].z));		
	}
	printf("���� �� vertex ����: %d\n", f3Vertices.size());
	printf("���� �� facet ����: %d\n", mesh->mNumFaces);	

	// ���� �𵨿��� ������ ���ؽ� ����Ʈ�κ��� 
	// �ߺ��Ǵ� ���ؽ� ������ ��, ���ؽ� �� �ε��� ����Ʈ �����	
	std::vector<Point_3>						vertices;
	std::vector<boost::tuple<int, int, int>>	facets;
	std::map<Point_3, int>						vertex_map;

	Point_3	point;
	int		ijk[3];
	int		count = 0;
	int		index = 0;

	for(int i = 0; i < mesh->mNumFaces; i++)
	{
		for(int vtx = 0; vtx < 3; vtx++)
		{
			index = (i * 3) + vtx;
			point = Point_3(f3Vertices[index].x, f3Vertices[index].y, f3Vertices[index].z);		

			if(vertex_map.find(point) == vertex_map.end())
			{
				ijk[vtx] = count;
				vertex_map[point] = count;
				vertices.push_back(point);
				count++;
			} 
			else
			{
				ijk[vtx] = vertex_map[point];
			}				
		}

		facets.push_back(boost::make_tuple(ijk[0], ijk[1], ijk[2]));		
	}

	// Polyhedron �����
	BuildFromSVXPrimitve<Polyhedron::HalfedgeDS> svx_builder(vertices, facets);
	m_Polyhedron.delegate(svx_builder);
	
	if(m_Polyhedron.is_valid())
		printf("Polyhedron is valid\n");
	else
		printf("Polyhedron is invalid\n");

	// �ӽ÷� �� ����
	for(Facet_iterator fit = m_Polyhedron.facets_begin(); fit != m_Polyhedron.facets_end(); fit++)
	{
		Polyhedron::Halfedge_around_facet_circulator facet_circulator = fit->facet_begin();
		facet_circulator->facet()->setFacetColor(createColor(200, 200, 200));
	}
	
	printf("Polyhedron ���� �Ϸ�\n\n");
}
//-------------------------------------------------------------------------------------------------------------------------------
// resetVisit
//-------------------------------------------------------------------------------------------------------------------------------
void CMesh::resetVisit()
{
	for(Facet_iterator fit = m_Polyhedron.facets_begin(); fit != m_Polyhedron.facets_end(); fit++)
	{
		Polyhedron::Halfedge_around_facet_circulator facet_circulator = fit->facet_begin();

		facet_circulator->facet()->setVisited(false);
	}
}
//-------------------------------------------------------------------------------------------------------------------------------
// AutoSegmentation
//-------------------------------------------------------------------------------------------------------------------------------

// for segmentAroundAFacet----> later recursion will be removed
CSegment * g_pSegment;
double g_threshold; 
D3DXVECTOR3 g_average_normal;
unsigned long g_facetColor;
int g_segmentID;
// for segmentAroundAFacet----> later recursion will be removed

void CMesh::autoSegmentation(float threshold)
{
	printf("AutoSegmentation �۾� ���� \n");
	printf("Threshold : %f\n", threshold);

	std::vector<Polyhedron> polyhedron_vector;
	std::for_each(m_Polyhedron.facets_begin(), m_Polyhedron.facets_end(), Facet_normal());
	int segmentID = 0;	
	unsigned long facetColor;

	for(Facet_iterator fit = m_Polyhedron.facets_begin(); fit != m_Polyhedron.facets_end(); fit++)
	{
		Polyhedron::Halfedge_around_facet_circulator facet_circulator = fit->facet_begin();

		if(!(fit->is_visited()))
		{
			CSegment *segment = new CSegment();
			m_pSegments->addSegment(segment);
			
			segment->setSegmentID(segmentID);
			facetColor = createColor();
			segment->setSegmentColor(facetColor);

			D3DXVECTOR3 average_normal;
			average_normal.x = facet_circulator->facet()->normal().x();
			average_normal.y = facet_circulator->facet()->normal().y();
			average_normal.z = facet_circulator->facet()->normal().z();	
			
			// for segmentAroundAFacet----> later recursion will be removed
			g_pSegment= segment;
			g_threshold = threshold; 
			g_average_normal = average_normal;
			g_facetColor = facetColor;
			g_segmentID = segmentID;
			//for segmentAroundAFacet----> later recursion will be removed

			CMesh::segmentAroundAFacet(facet_circulator, 1);
			
			segment->generateVertexVectorFromFacetsVector();
			segmentID++;
		}
	}	
	
	
	printf("End generatePolydedronFromFacetsVector\n");
	printf("AutoSegmentation �۾� �Ϸ� \n\n");
}




void CMesh::segmentAroundAFacet(
	const Polyhedron::Halfedge_around_facet_circulator facet_circulator, 
	int call_depth)
{
	Polyhedron::Facet_handle center_facet_handle = facet_circulator->facet();
    g_average_normal.x = (g_average_normal.x*g_pSegment->size() + center_facet_handle->normal().x())/(g_pSegment->size()+1);
	g_average_normal.y = (g_average_normal.y*g_pSegment->size() + center_facet_handle->normal().y())/(g_pSegment->size()+1);
	g_average_normal.z = (g_average_normal.z*g_pSegment->size() + center_facet_handle->normal().z())/(g_pSegment->size()+1);
	
	center_facet_handle->setVisited(true);
	center_facet_handle->setFacetColor(g_facetColor);
	center_facet_handle->setFacetId(g_segmentID);
	g_pSegment->addFacet(center_facet_handle);	
	
#ifdef _DEBUG
	if(call_depth > MAX_CALL_DEPTH)
		return; 
#endif

	Polyhedron::Halfedge_handle currEdge;

	int i;
	currEdge = facet_circulator->facet_begin();

	D3DXVECTOR3 curr_normal;
	for ( i=0; i < facet_circulator->facet_degree() ; currEdge = currEdge->next(), i++){
		if (!currEdge->opposite()->facet_begin()->facet()->is_visited()) 
		{
        	float x1 = currEdge->opposite()->facet_begin()->facet()->normal().x();
			float y1 = currEdge->opposite()->facet_begin()->facet()->normal().y();
			float z1 = currEdge->opposite()->facet_begin()->facet()->normal().z();

			 curr_normal = D3DXVECTOR3(x1, y1, z1);
			float inner_product = g_average_normal.x*curr_normal.x + g_average_normal.y*curr_normal.y + g_average_normal.z*curr_normal.z; 

			if (inner_product > g_threshold) 
			{
				segmentAroundAFacet(currEdge->opposite()->facet_begin(), call_depth+1);
			}
		}
	}
}
//-------------------------------------------------------------------------------------------------------------------------------
// Merge
//-------------------------------------------------------------------------------------------------------------------------------
void CMesh::Merge()
{
	if(m_pSegments == NULL)
		return;
	printf("Start Merge\n");
	CMesh::mergeSegment();
	InitVertexBuffer();
	printf("End Merge\n");
}
void CMesh::mergeSegment()
{
	std::vector<CSegment*>::iterator itr = m_pSegments->m_SegmentVector.begin();
	CSegment *p_segment = new CSegment();

	unsigned long color = 0;	

	for(; itr != m_pSegments->m_SegmentVector.end(); )
	{
		if((*itr)->isSelected() == true)
		{			
			color = (*itr)->getSegmentColor();

			std::vector<Polyhedron::Facet_handle>::iterator F_handle = (*itr)->m_Facet_vector.begin();
			for(; F_handle != (*itr)->m_Facet_vector.end(); ++F_handle)
			{
				p_segment->addFacet((*F_handle));
			}
			itr = m_pSegments->m_SegmentVector.erase(itr);
			p_segment->generateVertexVectorFromFacetsVector();
		}
		else
			++itr;
	}
	
	//���õ� Merge�� ��� Segment ���� ��
	if(p_segment->size() > 0)
	{
		int id = 0;
		
		//p_segments->addSegment(p_segment);
		printf("Merge �� Segments�� ����\n");
		printf("p_segment size - F : %d\tV : %d\n", p_segment->m_Facet_vector.size(), p_segment->m_Vertex_vector.size());
		printf("p_Segments size : %d\n", m_pSegments->size());
		p_segment->setSegmentColor(color);
		m_pSegments->addSegment(p_segment);
		printf("Merge �� m_pSegments size : %d\n", m_pSegments->size());					

		std::vector<CSegment*>::iterator Sitr = m_pSegments->m_SegmentVector.begin();
		for(; Sitr != m_pSegments->m_SegmentVector.end(); ++Sitr)
		{
			(*Sitr)->setSegmentID(id);
			printf("id                   : %d\n", (*Sitr)->getSegmentID());
			printf("Facet_vector    size : %d\n", (*Sitr)->m_Facet_vector.size());
			printf("m_Vertex_vector size : %d\n", (*Sitr)->m_Vertex_vector.size());
			
			std::vector<Polyhedron::Facet_handle>::iterator itr = (*Sitr)->m_Facet_vector.begin();
			
			for(; itr != (*Sitr)->m_Facet_vector.end(); ++itr)
			{
				(*itr)->setFacetId(id);				
				//printf("Facet id : %d\n", (*itr)->getFacetId());
			}
			id++;
		}
	}
	else
	{
		printf("Merge�� Segemts�� ����.\n");
	}
}

//-------------------------------------------------------------------------------------------------------------------------------
// Split
//-------------------------------------------------------------------------------------------------------------------------------
void CMesh::Split(Point_3 point1, Point_3 point2, Point_3 point3)
{
	if(m_pSegments == NULL)
		return;

	//Point_3 point1(-0.1, 0.2, 0.0);
	//Point_3 point2(1.0, 0.2, 1.0);
	//Point_3 point3(-1.0, -1.0, -1.0);

	printf("Start split Segment\n");
	splitWithLineSegment(point1, point2, point3);
	InitVertexBuffer();
	printf("End split Segment\n");
}


void CMesh::splitWithLineSegment(Point_3 point1, Point_3 point2, Point_3 point3)
{
	std::vector<CSegment*>::iterator itr = m_pSegments->m_SegmentVector.begin();
	
	for(; itr != m_pSegments->m_SegmentVector.end(); ++itr)
	{
		if((*itr)->isSelected() == true)
		{			
			std::map<Polyhedron::Facet_handle, Point_3> center_of_facet_map;
			printf("���õ� Segment �߰�\n");
			std::vector<Polyhedron::Facet_handle>::iterator FH_itr = (*itr)->m_Facet_vector.begin();
			for(; FH_itr != (*itr)->m_Facet_vector.end(); ++FH_itr)
			{
				Point_3 p1 = (*FH_itr)->halfedge()->vertex()->point();
				Point_3 p2 = (*FH_itr)->halfedge()->next()->vertex()->point();
				Point_3 p3 = (*FH_itr)->halfedge()->next()->next()->vertex()->point();
				
				center_of_facet_map[(*FH_itr)] = Point_3((p1.x() + p2.x() + p3.x()) / 3, (p1.y() + p2.y() + p3.y()) / 3, (p1.z() + p2.z() + p3.z()) / 3);
			}

			Plane_3 plane(point1, point2, point3);

			CSegment* nSegment = new CSegment();
			CSegment* pSegment = new CSegment();
			
			std::map<Polyhedron::Facet_handle, Point_3>::iterator mit = center_of_facet_map.begin();
			for(; mit != center_of_facet_map.end(); ++mit)
			{
				Point_3 point = mit->second;
				if(plane.has_on_negative_side(point))
				{
					nSegment->addFacet(mit->first);
				}
				else
				{
					pSegment->addFacet(mit->first);
				}
			}
			nSegment->generateVertexVectorFromFacetsVector();
			pSegment->generateVertexVectorFromFacetsVector();


			nSegment->setSegmentColor((*itr)->getSegmentColor());
			pSegment->setSegmentColor(createColor());

			if(nSegment->size() > 0)
			{
				//printf("nSegment size : %d\n", nSegment->size());
				m_pSegments->addSegment(nSegment);
			}
			if(pSegment->size() > 0)
			{
				//printf("pSegment size : %d\n", nSegment->size());
				m_pSegments->addSegment(pSegment);
			}
		}
	}

	//���õ�(Split �� ����) Semgent ����
	printf("���õ�(Split �� ����) ����.\n");
	std::vector<CSegment*>::iterator segment_erase_iterator = m_pSegments->m_SegmentVector.begin();
	for(; segment_erase_iterator != m_pSegments->m_SegmentVector.end(); )
	{
		if((*segment_erase_iterator)->isSelected() == true)
		{			
			segment_erase_iterator = m_pSegments->m_SegmentVector.erase(segment_erase_iterator);
		}
		else
			++segment_erase_iterator;
	}


	//Segment �� Facet ID �� ����
	printf("Segment �� Facet ID �� ����.\n");
	int id = 0;
	std::vector<CSegment*>::iterator set_id_iterator = m_pSegments->m_SegmentVector.begin();
	for(; set_id_iterator != m_pSegments->m_SegmentVector.end(); ++set_id_iterator)
	{
		(*set_id_iterator)->setSegmentID(id);
		//printf("id                   : %d\n", (*set_id_iterator)->getSegmentID());
		//printf("Facet_vector    size : %d\n", (*set_id_iterator)->m_Facet_vector.size());
		//printf("m_Vertex_vector size : %d\n", (*set_id_iterator)->m_Vertex_vector.size());
		
		std::vector<Polyhedron::Facet_handle>::iterator Fit = (*set_id_iterator)->m_Facet_vector.begin();
		
		for(; Fit != (*set_id_iterator)->m_Facet_vector.end(); ++Fit)
		{
			(*Fit)->setFacetId(id);				
			//printf("Facet id : %d\n", (*Fit)->getFacetId());
		}
		id++;
	}
}
//-------------------------------------------------------------------------------------------------------------------------------
// Flatten
//-------------------------------------------------------------------------------------------------------------------------------
void CMesh::Flatten()
{
	printf("Start FlattenSegment\n");
	CMesh::flattenSegment();
	InitVertexBuffer();
	printf("End FlattenSegment\n");
}
void CMesh::flattenSegment()
{
	std::vector<CSegment*>::iterator itr = m_pSegments->m_SegmentVector.begin();
	std::for_each(m_Polyhedron.facets_begin(), m_Polyhedron.facets_end(), Facet_normal());
	
	for(; itr != m_pSegments->m_SegmentVector.end(); ++itr)
	{
		if((*itr)->isSelected() == true)
		{
			D3DXVECTOR3 average_normal = D3DXVECTOR3(0, 0, 0);

			std::vector<Polyhedron::Facet_handle>::iterator facet_itr = (*itr)->m_Facet_vector.begin();
			for(; facet_itr != (*itr)->m_Facet_vector.end(); ++facet_itr)
			{
				average_normal.x += (*facet_itr)->normal().x();
				average_normal.y += (*facet_itr)->normal().y();
				average_normal.z += (*facet_itr)->normal().z();
			}
			
			average_normal /= sqrt(average_normal.x*average_normal.x + average_normal.y*average_normal.y + average_normal.z*average_normal.z);

			float average_dot = 0;
			D3DXVECTOR3 pos;
			int size_of_vertices = 0;

			facet_itr = (*itr)->m_Facet_vector.begin();
			for(; facet_itr != (*itr)->m_Facet_vector.end(); ++facet_itr)
			{
				std::vector<Polyhedron::Vertex_handle>::iterator vertex_itr = (*itr)->m_Vertex_vector.begin();
				for(; vertex_itr != (*itr)->m_Vertex_vector.end(); ++vertex_itr)
				{
					pos = D3DXVECTOR3((*vertex_itr)->point().x(), (*vertex_itr)->point().y(), (*vertex_itr)->point().z());
					float dot = pos.x*average_normal.x + pos.y*average_normal.y+ pos.z*average_normal.z;
					average_dot += dot;
					size_of_vertices += 1;
				}
			}
			average_dot /= size_of_vertices;

			facet_itr = (*itr)->m_Facet_vector.begin();
			for(; facet_itr != (*itr)->m_Facet_vector.end(); ++facet_itr)
			{
				std::vector<Polyhedron::Vertex_handle>::iterator vertex_itr = (*itr)->m_Vertex_vector.begin();
				for(; vertex_itr != (*itr)->m_Vertex_vector.end(); ++vertex_itr)
				{
					pos = D3DXVECTOR3((*vertex_itr)->point().x(), (*vertex_itr)->point().y(), (*vertex_itr)->point().z());
					float dot = pos.x*average_normal.x + pos.y*average_normal.y+ pos.z*average_normal.z;
					float diff = average_dot-dot;
					D3DXVECTOR3 new_pos = pos + average_normal*diff;
					D3DXVECTOR3 translation_amount = new_pos-pos;
					(*vertex_itr)->point() = Point_3(new_pos.x, new_pos.y, new_pos.z);
				}
			}
		}
	}
}
//-------------------------------------------------------------------------------------------------------------------------------
// ���õ� facet id�� ���õ� segment�� id ����
//-------------------------------------------------------------------------------------------------------------------------------
int CMesh::GetSelectedSegmentId(int facetId)
{
	CSegment* segment;

	for(int i = 0; i < m_pSegments->m_SegmentVector.size(); i++)
	{
		segment = m_pSegments->m_SegmentVector[i];
		if(facetId == segment->getSegmentID())
			return i;	
	}

	return -1;
}

//-------------------------------------------------------------------------------------------------------------------------------
// Segment ��������
//-------------------------------------------------------------------------------------------------------------------------------
void CMesh::SelectSegment(int segmentId)
{
	CSegment* segment = m_pSegments->m_SegmentVector[segmentId];

	if(segment->isSelected()) 
	{
		segment->deselect();
		segment->updateFacetColor(segment->getSegmentColor());
	}
	else
	{
		segment->select();
		segment->updateFacetColor(m_SelectedSegmentColor);
	}
}

//-------------------------------------------------------------------------------------------------------------------------------
// ������ ����
//-------------------------------------------------------------------------------------------------------------------------------
unsigned long CMesh::createColor(void) {
	int r, g, b;		
	do 
	{
		r = rand()%256;
		g = rand()%256;
		b = rand()%256;
	} while (r>200 && g<50 && b<50);

	return ((r & 0xff) << 16) + ((g & 0xff) << 8) + (b & 0xff);
}

//-------------------------------------------------------------------------------------------------------------------------------
//
//-------------------------------------------------------------------------------------------------------------------------------
unsigned long CMesh::createColor(int r, int g, int b) {
	return ((r & 0xff) << 16) + ((g & 0xff) << 8) + (b & 0xff);
}

//-------------------------------------------------------------------------------------------------------------------------------
// ������
//-------------------------------------------------------------------------------------------------------------------------------
CMesh::CMesh(LPDIRECT3DDEVICE9 pD3DDevice, char* path)
:m_pD3DDevice(pD3DDevice), m_pFilePath(path)
{
	D3DXMatrixIdentity(&m_mScale);
	D3DXMatrixIdentity(&m_mRotation);
	D3DXMatrixIdentity(&m_mTranslation);

	//D3DXMatrixScaling(&m_mScale, 2.f, 2.f, 2.f);

	m_mWorld = m_mScale * m_mRotation * m_mTranslation;

	m_pVertexBuffer = NULL;	
	CreateSegments();
}

//-------------------------------------------------------------------------------------------------------------------------------
// �Ҹ���
//-------------------------------------------------------------------------------------------------------------------------------
CMesh::~CMesh(void)
{	
	SAFE_RELEASE(m_pVertexBuffer);
}

//-------------------------------------------------------------------------------------------------------------------------------
// ���ؽ� ���� ����
//-------------------------------------------------------------------------------------------------------------------------------
HRESULT	CMesh::InitVertexBuffer(void)
{
	SAFE_RELEASE(m_pVertexBuffer);

	const uint num = uint(3 * m_Polyhedron.size_of_facets());
	CUSTOMVERTEX* vertices = new CUSTOMVERTEX[num];
	float* normal;
	int row = 0;
	int column = 0;
	Polyhedron::Halfedge_around_facet_circulator facet_cir;
	for(Polyhedron::Facet_iterator f = m_Polyhedron.facets_begin(); f != m_Polyhedron.facets_end(); ++f)
	{
		facet_cir = f->facet_begin();

		if(CGAL::circulator_size(facet_cir) == 3) 
		{
			column = 0;
			do
			{
				vertices[row*3+column].position = D3DXVECTOR3(
					facet_cir->vertex()->point().x(), 
					facet_cir->vertex()->point().y(), 
					facet_cir->vertex()->point().z());
				
				vertices[row*3+column].color = facet_cir->facet()->getFacetColor();

				normal = facet_cir->facet()->getNormal();				
				vertices[row*3+column].normal = D3DXVECTOR3(normal[0], normal[1], normal[2]);

				++column;
			} while(++facet_cir != f->facet_begin());
		}
		else
		{ }
		++row;
	}

	// VB ����
	if(FAILED(m_pD3DDevice->CreateVertexBuffer(
		num*sizeof(CUSTOMVERTEX), 0, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT, &m_pVertexBuffer, NULL)))
	{
		return E_FAIL;
	}

	const int size = num * sizeof(CUSTOMVERTEX);

	VOID* pVertices;
	if(FAILED(m_pVertexBuffer->Lock(0, size, (void**)&pVertices, 0)))
	{
		return E_FAIL;
	}
	memcpy(pVertices, vertices, size);
	m_pVertexBuffer->Unlock();

	SAFE_DELETE_ARRAY(vertices);

	return S_OK;
}

//-------------------------------------------------------------------------------------------------------------------------------
// ������
//-------------------------------------------------------------------------------------------------------------------------------
void CMesh::Render(void)
{
	m_pD3DDevice->SetStreamSource(0, m_pVertexBuffer, 0, sizeof(CUSTOMVERTEX));

	m_pD3DDevice->SetFVF(D3DFVF_CUSTOMVERTEX);

	m_pD3DDevice->DrawPrimitive(D3DPT_TRIANGLELIST, 0, m_Polyhedron.size_of_facets() * 3);
}