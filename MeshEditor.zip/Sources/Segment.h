#pragma once
#include "CGALUtils/Define.h"

//using namespace std;
class CSegment
{	
private:
	/*void setFacet_vector(std::vector<Polyhedron::Facet_handle>);
	void setVertex_vector(std::vector<Polyhedron::Vertex_handle>);
	std::vector<Polyhedron::Facet_handle> getFacet_vector(void) { return m_Facet_vector; }
	std::vector<Polyhedron::Vertex_handle> getVertex_vector(void) { return m_Vertex_vector; }
	*/
	boolean			bSelected;
	int				nSegmentID;
	unsigned long	nSegmentColor;	

public:
	CSegment();
	~CSegment(void);

	std::vector<Polyhedron::Facet_handle>	m_Facet_vector;
	std::vector<Polyhedron::Vertex_handle>	m_Vertex_vector;
	int addFacet(Polyhedron::Facet_handle  facet);
	int generateVertexVectorFromFacetsVector();
	int size();
	boolean isSelected() { return bSelected;};
	int toggleSelection(){ bSelected =! bSelected; return 0;};
	int select(){ bSelected =true; return 0;};
	int deselect(){ bSelected =false; return 0;};
	void setVisited(boolean bVisit);
	void setSegmentID(int);
	int getSegmentID(void);
	void setSegmentColor(unsigned long);
	void updateFacetColor(unsigned long);
	unsigned long getSegmentColor(void) { return nSegmentColor; }
};