#pragma once
#include "Segment.h"

class CSegments
{
private:
	int m_SegmentID;
public:
	CSegments();
	~CSegments(void);
	int addSegment(CSegment* pSegment);
	int size();
	

//private:
	std::vector<CSegment*> m_SegmentVector;

	void setVisited(boolean bVisit);
	
	
};