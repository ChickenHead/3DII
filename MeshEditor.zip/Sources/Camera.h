#pragma once

#include "DXUTCamera.h"

class CCamera : public CModelViewerCamera
//class CCamera : public CFirstPersonCamera
{
public:
	CCamera(void){}
	~CCamera(void){}
};

